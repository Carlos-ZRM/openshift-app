# Introducción

- Proyecto Argo que crea una aplicaición pipeline (CI)
- Proyecto Argo que crea los objetos de openshift 