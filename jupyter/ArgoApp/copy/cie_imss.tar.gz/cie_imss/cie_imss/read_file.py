import pandas as pd
import numpy as np
from unidecode import unidecode
import re
from tqdm import tqdm
tqdm.pandas()


## Read and preprocessing data
def read_file(path):
    df = pd.read_pickle(path).reset_index(drop=True)
    cols = ['sexo', 'edad', 'res_ent', 'def_ent', 'causa_bas', 'des_causa_a',
            'des_causa_b', 'des_causa_c', 'causa_a', 'causa_b', 'causa_c']
    df = df[cols]

    def remove_characters(text):
        if isinstance(text, str):
            text = text.lower()
            text = unidecode(text)
            punctuation = '''|!()-[]{};:'"\,<>./?@#$%^&*_~'''
            text = text.translate(str.maketrans('', '', punctuation))
            text = re.sub(r'-','', text)
            text = text.strip()
        return text
    
    text_cols = ['des_causa_a', 'des_causa_b', 'des_causa_c']
    for col in text_cols:
        df[col] = df[col].apply(remove_characters)

    results = []
    for i, col in enumerate(text_cols):
        code_col = f'causa_{chr(97+i)}'
        result = df[['sexo', 'edad', 'res_ent', 'def_ent', 'causa_bas', col, code_col]].rename(
            columns={col: 'diagnostico', code_col: 'codigo'}
        ).dropna()
        results.append(result)

    result = pd.concat(results, ignore_index=True)
    result['codigo'] = result['codigo'].apply(remove_characters)
    result['len_codigo'] = result['codigo'].apply(lambda x: len(x.split()) if pd.notnull(x) else 0)
    
    #filter the first 100 causes
    result = result[(result.len_codigo == 1) & (result.codigo.isin(result.codigo.value_counts()[:30].index))]
    
    # Calculate frequencies and determine order
    value_counts = result['codigo'].value_counts()

    labels_mapping = {value: label for label, value in enumerate(value_counts.index)}

    # Apply the mapping to the dataframe to create a new 'label' column
    result['label'] = result['codigo'].map(labels_mapping)
    result = result[pd.notnull(result.codigo)].sort_values('label')
    result['causa'] = result.loc[:,['sexo','edad','diagnostico']].progress_apply(lambda x: ' '.join(x.astype(str)), axis=1)
    result = result[['diagnostico','codigo','label']]
    return result  