#!/bin/bash

set -x  # Debug mode: show each command being executed.

while read requirement; do
  echo "Attempting to install $requirement..."
  pip install "$requirement" || echo "Failed to install $requirement"
done < requirements.txt

echo "Script completed"

